import time
import random
import socket
import sys
import glob

def load_logs(file_paths):
    """Load normal logs from multiple provided files."""
    logs = []
    for file_path in file_paths:
        with open(file_path, 'r') as f:
            logs.extend([line.strip() for line in f if line.strip()])
    return logs

def load_malicious_values(file_path):
    """Load malicious values from a provided text file."""
    malicious_data = {}
    with open(file_path, 'r') as f:
        for line in f:
            key, value = line.strip().split('=')
            malicious_data[key] = value
    return malicious_data

def inject_malicious_log(normal_log, malicious_data):
    """Replace normal log values with malicious indicators."""
    for key, value in malicious_data.items():
        if key in normal_log:
            normal_log = normal_log.replace(key + "=" + normal_log.split(key + "=")[1].split('|')[0], key + "=" + value)
    return normal_log

def send_to_syslog_server(log, server_ip, server_port, protocol='udp'):
    """Send a log to the syslog server via UDP or TCP without modifying the format."""
    if protocol == 'udp':
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    else:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.connect((server_ip, server_port))
    
    sock.sendall(log.encode())
    sock.close()

def main(logs_dir, malicious_file, syslog_ip, syslog_port, eps=100, protocol='udp'):
    """Main function to forward logs from multiple files at the specified rate."""
    log_files = glob.glob(f"{logs_dir}/*.txt")  # Load all log files in the directory
    log_categories = {file: load_logs([file]) for file in log_files}
    malicious_data = load_malicious_values(malicious_file)
    
    while True:
        for category, logs in log_categories.items():
            for _ in range(eps):
                normal_log = random.choice(logs)
                send_to_syslog_server(normal_log, syslog_ip, syslog_port, protocol)
                
                # Inject malicious log for every 100 normal logs per category
                if random.randint(1, 100) == 1:
                    malicious_log = inject_malicious_log(random.choice(logs), malicious_data)
                    send_to_syslog_server(malicious_log, syslog_ip, syslog_port, protocol)
                    print(f"Injected Malicious Log from {category}: {malicious_log}")
            
        time.sleep(1)  # Ensuring 100 EPS per category

if __name__ == "__main__":
    if len(sys.argv) < 5:
        print("Usage: python log_forwarder.py <logs_directory> <malicious_values_file> <syslog_ip> <syslog_port> [eps] [protocol]")
        sys.exit(1)
    
    logs_directory = sys.argv[1]
    malicious_file = sys.argv[2]
    syslog_ip = sys.argv[3]
    syslog_port = int(sys.argv[4])
    eps = int(sys.argv[5]) if len(sys.argv) > 5 else 100
    protocol = sys.argv[6] if len(sys.argv) > 6 else 'udp'
    
    main(logs_directory, malicious_file, syslog_ip, syslog_port, eps, protocol)

